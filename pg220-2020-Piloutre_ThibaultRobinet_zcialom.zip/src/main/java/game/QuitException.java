package game;

public class QuitException extends Exception{
    public QuitException() {
        super();
    }
}
