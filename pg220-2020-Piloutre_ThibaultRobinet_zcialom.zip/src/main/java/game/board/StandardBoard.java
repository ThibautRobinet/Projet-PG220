package game.board;

public final class StandardBoard extends Board {
	public StandardBoard(){
		super(6,7);
	}
}

	